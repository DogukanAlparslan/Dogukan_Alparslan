*/
*Doğukan Alparslan
*22.01.2022
*
*This project contains about function minimum value,maximum value,median value,*mean value and sorted array.
*"stats.h" file contains all about functions."stats.c" contains source code about solutions.
*/

