/**
*stats.h
*
*This file contains functions about min value, max value, mean value,
*median value and sort from largest to lowest.
*
*Do�ukan Alparslan
*22.01.2022
*/
#ifndef __stats_h__
#define __stats_h__

//Function of minimum of array
int min(unsigned char test[],int size){
    int min=1000000;
    int i=0;
    for(i=0;i<size;i++){
        if(min>test[i]){
            min=test[i];
        }
    }
    printf("Min value:%d\n",min);
}
//Function of maximum of array
int max(unsigned char test[],int size){
    int max=0;
    int i;
    for(i=0;i<size;i++){
        if(max<test[i]){
            max=test[i];
        }
    }
    printf("Max value:%d\n",max);
}
//Function of mean of array
int mean(unsigned char test[],int size){
    float sum = 0;
    float mean;
    int i;
    for(i=0;i<size;i++){
        sum =sum+test[i];
    }
    mean=(sum/size);
    printf("mean value:%f\n",mean);
}
//Function which contains sorted array from largest to lowest and find median of array
int median(unsigned char test[],int size){
    int temp=0;
    int median=0;
    //sorted array
    for(int i=0;i<size;i++){
        for(int j=0;j<size-1;j++){
            if(test[j]<test[j+1]){
                temp= test[j+1];
                test[j+1]=test[j];
                test[j]=temp;
            }
        }
    }
    median = (test[(size/2)-1]+test[(size/2)+1])/2;
    printf("median value:%d\n",median);
}
//Function about sort from largest to lowest
int sort(unsigned char test[],int size){
    int temp=0;
    for(int i=0;i<size;i++){
        for(int j=0;j<size-1;j++){
            if(test[j]<test[j+1]){
                temp= test[j+1];
                test[j+1]=test[j];
                test[j]=temp;
            }
        }
    }
    printf("sorted:");
    for(int i=0;i<size;i++){
        printf("%d ",test[i]);
    }
}
int print_array(unsigned char test[],int size){
    printf("array:");
    for(int i=0;i<size;i++){
        printf("%d ",test[i]);
    }
    printf("\n");
}
#endif /*stats.h*/
