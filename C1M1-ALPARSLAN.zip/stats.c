/*
*stats.c
*File contains an array of 40 characters and functions about this array

*Dogukan Alparslan
*22.01.2022
*/

#include <stdio.h>
#include <stdlib.h>
#include "stats.h"
#define SIZE (40)
void main()
{  //Given Array
   unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                                114, 88,   45,  76, 123,  87,  25,  23,
                                200, 122, 150, 90,   92,  87, 177, 244,
                                201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};

    //calling functions from "stats.h"
    print_array(test,SIZE);//returns array
    min(test,SIZE); //returns min value
    max(test,SIZE); //returns max value
    mean(test,SIZE); // returns mean value
    median(test,SIZE);//returns median value
    sort(test,SIZE); //returns sorted from largest to lowest array
return ;
}
